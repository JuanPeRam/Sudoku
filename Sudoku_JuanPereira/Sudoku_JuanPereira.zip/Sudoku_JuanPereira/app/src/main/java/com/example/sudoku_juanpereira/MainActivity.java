package com.example.sudoku_juanpereira;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Handler handler = new Handler();
        Intent main = new Intent(this, Home.class);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(main);
                finish();
            }
        }, 3000);
    }
}